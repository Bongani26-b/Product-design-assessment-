/**
 * KASI DISTRIBUTORS OPERATIONS SYSTEM
 * Main Logic Script with Auth, Users & Modals
 */

// ==========================================
// MOCK DATA & STATE
// ==========================================

let appUsers = [];
let currentUser = null;

let inventory = [
    { id: 'PRD-001', name: 'Maize Meal 10kg', sku: 'MZ-10', price: 95.00, stock: 150, image: 'https://via.placeholder.com/150/EEEEEE/808080?text=Maize+Meal' },
    { id: 'PRD-002', name: 'Cooking Oil 2L', sku: 'CO-2L', price: 45.50, stock: 45, image: 'https://via.placeholder.com/150/EEEEEE/808080?text=Oil' },
    { id: 'PRD-003', name: 'Sugar 5kg', sku: 'SG-5K', price: 85.00, stock: 8, image: 'https://via.placeholder.com/150/EEEEEE/808080?text=Sugar' },
    { id: 'PRD-004', name: 'Baked Beans 410g', sku: 'BB-C12', price: 140.00, stock: 200, image: 'https://via.placeholder.com/150/EEEEEE/808080?text=Beans' }
];

let orders = [
    { id: 'ORD-1001', customer: 'Sipho Spaza', date: '2026-04-29', items: 3, total: 450.00, status: 'Pending', paymentMethod: 'Cash' },
    { id: 'ORD-1002', customer: 'Mama Joy', date: '2026-04-29', items: 12, total: 1250.00, status: 'Processing', paymentMethod: 'Card' }
];

let cart = [];

// ==========================================
// DOM ELEMENTS
// ==========================================

// Containers
const authContainer = document.getElementById('auth-container');
const appContainer = document.getElementById('app-container');
const adminNavSection = document.getElementById('admin-nav-section');

// Auth Form
const authForm = document.getElementById('auth-form');
const authNameGroup = document.getElementById('auth-name-group');
const authName = document.getElementById('auth-name');
const authEmail = document.getElementById('auth-email');
const authPassword = document.getElementById('auth-password');
const authSubmitBtn = document.getElementById('auth-submit-btn');
const authSubtitle = document.getElementById('auth-subtitle');
const logoutBtn = document.getElementById('logout-btn');

// Topbar & Sidebar
const sidebar = document.getElementById('sidebar');
const mobileMenuBtn = document.getElementById('mobile-menu-btn');
const sidebarUserRole = document.getElementById('sidebar-user-role');
const topbarAvatar = document.getElementById('topbar-avatar');
const dashboardWelcomeMsg = document.getElementById('dashboard-welcome-msg');
const navItems = document.querySelectorAll('.nav-item');
const viewSections = document.querySelectorAll('.view-section');

// Dashboard Elements
const dashPendingOrders = document.getElementById('dash-pending-orders');
const dashCompletedOrders = document.getElementById('dash-completed-orders');
const dashLowStock = document.getElementById('dash-low-stock');
const dashTotalSales = document.getElementById('dash-total-sales');
const dashboardOrdersTable = document.querySelector('#dashboard-orders-table tbody');
const dashboardLowStockList = document.getElementById('dashboard-low-stock-list');

// Orders View
const allOrdersTable = document.querySelector('#all-orders-table tbody');

// Inventory View
const inventoryTable = document.querySelector('#inventory-table tbody');

// Payments View
const paymentsTable = document.querySelector('#payments-table tbody');
const totalCashPayments = document.getElementById('total-cash-payments');
const totalCardPayments = document.getElementById('total-card-payments');

// Users View (Admin Only)
const usersTable = document.querySelector('#users-table tbody');

// Modals
const addProductModal = document.getElementById('add-product-modal');
const openAddProductBtn = document.getElementById('open-add-product-btn');
const closeAddProductBtn = document.getElementById('close-add-product-btn');
const addProductForm = document.getElementById('add-product-form');

const addUserModal = document.getElementById('add-user-modal');
const openAddUserBtn = document.getElementById('open-add-user-btn');
const closeAddUserBtn = document.getElementById('close-add-user-btn');
const addUserForm = document.getElementById('add-user-form');

// Customer Elements
const customerSimulation = document.getElementById('customer-simulation');
const switchCustomerBtn = document.getElementById('switch-to-customer-btn');
const returnAdminBtn = document.getElementById('return-admin-btn');
const customerProductGrid = document.getElementById('customer-product-grid');
const cartCount = document.getElementById('cart-count');
const cartSidebar = document.getElementById('cart-sidebar');
const cartOverlay = document.getElementById('cart-overlay');
const openCartBtn = document.getElementById('open-cart-btn');
const closeCartBtn = document.getElementById('close-cart-btn');
const cartItemsContainer = document.getElementById('cart-items-container');
const cartTotalAmount = document.getElementById('cart-total-amount');
const checkoutBtn = document.getElementById('checkout-btn');

const checkoutModal = document.getElementById('checkout-modal');
const cancelCheckoutBtn = document.getElementById('cancel-checkout-btn');
const confirmOrderBtn = document.getElementById('confirm-order-btn');
const checkoutSpazaName = document.getElementById('checkout-spaza-name');
const checkoutPaymentMethod = document.getElementById('checkout-payment-method');

// Toast
const toastNotification = document.getElementById('toast-notification');
const toastMessage = document.getElementById('toast-message');

// ==========================================
// INITIALIZATION
// ==========================================

function init() {
    checkAuthState();
    setupNavigation();
    setupModals();
}

// ==========================================
// AUTH LOGIC
// ==========================================

function checkAuthState() {
    if(appUsers.length === 0) {
        // Setup initial Admin signup
        authNameGroup.classList.remove('hidden');
        authName.required = true;
        authSubtitle.textContent = "Welcome! Please sign up as the First Admin.";
        authSubmitBtn.textContent = "Create Admin Account";
    } else {
        // Normal login
        authNameGroup.classList.add('hidden');
        authName.required = false;
        authSubtitle.textContent = "Please log in to your account.";
        authSubmitBtn.textContent = "Login";
    }
}

authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = authEmail.value.trim();
    const password = authPassword.value;

    if(appUsers.length === 0) {
        // First Admin creation
        const name = authName.value.trim();
        const newAdmin = {
            id: 'USR-1',
            name: name,
            email: email,
            password: password,
            role: 'Admin',
            status: 'Active'
        };
        appUsers.push(newAdmin);
        currentUser = newAdmin;
        showToast("Admin account created successfully!");
        loginSuccess();
    } else {
        // Standard login
        const user = appUsers.find(u => u.email === email && u.password === password);
        if(user) {
            if(user.status === 'Inactive') {
                alert("Your account is deactivated. Contact Admin.");
                return;
            }
            currentUser = user;
            showToast("Login successful!");
            loginSuccess();
        } else {
            alert("Invalid email or password!");
        }
    }
});

logoutBtn.addEventListener('click', () => {
    currentUser = null;
    appContainer.classList.add('hidden');
    authContainer.classList.remove('hidden');
    authForm.reset();
    checkAuthState();
});

function loginSuccess() {
    authContainer.classList.add('hidden');
    appContainer.classList.remove('hidden');
    
    // Set user profile info
    sidebarUserRole.textContent = `${currentUser.role}: ${currentUser.name.split(' ')[0]}`;
    topbarAvatar.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}&background=0D8ABC&color=fff`;
    dashboardWelcomeMsg.textContent = `Welcome back, ${currentUser.name}. Here is today's summary.`;

    // Role-based visibility
    if(currentUser.role === 'Admin') {
        adminNavSection.style.display = 'block';
    } else {
        adminNavSection.style.display = 'none';
        // If they were on users view, push them to dashboard
        switchView('dashboard-view');
    }

    // Render App
    renderDashboard();
    renderOrders();
    renderInventory();
    renderPayments();
    renderUsers();
    renderCustomerProducts();
}

// ==========================================
// NAVIGATION LOGIC
// ==========================================

function setupNavigation() {
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = item.getAttribute('data-target');
            if(targetId) switchView(targetId);
            if(window.innerWidth <= 768) sidebar.classList.remove('open');
        });
    });

    if(mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }

    switchCustomerBtn.addEventListener('click', () => {
        customerSimulation.classList.remove('hidden');
    });

    returnAdminBtn.addEventListener('click', () => {
        customerSimulation.classList.add('hidden');
        renderDashboard();
        renderOrders();
    });
}

function switchView(viewId) {
    navItems.forEach(item => {
        if(item.getAttribute('data-target') === viewId) item.classList.add('active');
        else item.classList.remove('active');
    });

    viewSections.forEach(section => {
        if(section.id === viewId) section.classList.add('active');
        else section.classList.remove('active');
    });
}

// ==========================================
// MODAL LOGIC
// ==========================================
function setupModals() {
    // Add Product Modal
    openAddProductBtn.addEventListener('click', () => addProductModal.classList.remove('hidden'));
    closeAddProductBtn.addEventListener('click', () => addProductModal.classList.add('hidden'));
    
    // Add User Modal
    openAddUserBtn.addEventListener('click', () => addUserModal.classList.remove('hidden'));
    closeAddUserBtn.addEventListener('click', () => addUserModal.classList.add('hidden'));

    // Handle Form Submits
    addProductForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('new-prod-name').value;
        const sku = document.getElementById('new-prod-sku').value;
        const price = parseFloat(document.getElementById('new-prod-price').value);
        const stock = parseInt(document.getElementById('new-prod-stock').value);

        const newProd = {
            id: `PRD-00${inventory.length + 1}`,
            name: name,
            sku: sku,
            price: price,
            stock: stock,
            image: `https://via.placeholder.com/150/EEEEEE/808080?text=${encodeURIComponent(name.substring(0,8))}`
        };

        inventory.push(newProd);
        addProductModal.classList.add('hidden');
        addProductForm.reset();
        
        showToast("Product added successfully!");
        renderInventory();
        renderCustomerProducts();
        renderDashboard();
    });

    addUserForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('new-user-name').value;
        const email = document.getElementById('new-user-email').value;
        const password = document.getElementById('new-user-password').value;
        const role = document.getElementById('new-user-role').value;

        // Check email exists
        if(appUsers.find(u => u.email === email)) {
            alert("Email already exists!");
            return;
        }

        const newUser = {
            id: `USR-${appUsers.length + 1}`,
            name: name,
            email: email,
            password: password,
            role: role,
            status: 'Active'
        };

        appUsers.push(newUser);
        addUserModal.classList.add('hidden');
        addUserForm.reset();
        
        showToast("User added successfully!");
        renderUsers();
    });
}


// ==========================================
// VIEW RENDERING
// ==========================================

function renderDashboard() {
    const pending = orders.filter(o => o.status === 'Pending').length;
    const completed = orders.filter(o => o.status === 'Delivered').length;
    const totalSales = orders.reduce((sum, o) => sum + o.total, 0);
    const lowStockItems = inventory.filter(p => p.stock < 20);

    dashPendingOrders.textContent = pending;
    dashCompletedOrders.textContent = completed;
    dashTotalSales.textContent = `R ${totalSales.toLocaleString()}`;
    dashLowStock.textContent = lowStockItems.length;

    dashboardOrdersTable.innerHTML = '';
    orders.slice(0, 4).forEach(order => {
        dashboardOrdersTable.innerHTML += `
            <tr>
                <td><strong>${order.id}</strong></td>
                <td>${order.customer}</td>
                <td>R ${order.total.toFixed(2)}</td>
                <td><span class="status-badge status-${order.status.toLowerCase()}">${order.status}</span></td>
            </tr>
        `;
    });

    dashboardLowStockList.innerHTML = '';
    if(lowStockItems.length === 0) {
        dashboardLowStockList.innerHTML = '<p class="text-muted p-3">No low stock items.</p>';
    } else {
        lowStockItems.forEach(item => {
            dashboardLowStockList.innerHTML += `
                <div class="low-stock-item">
                    <div class="ls-info">
                        <h4>${item.name}</h4><p>SKU: ${item.sku}</p>
                    </div>
                    <div class="ls-qty"><span class="status-badge status-low-stock">${item.stock} left</span></div>
                </div>`;
        });
    }
}

function renderOrders() {
    allOrdersTable.innerHTML = '';
    orders.forEach(order => {
        allOrdersTable.innerHTML += `
            <tr>
                <td><strong>${order.id}</strong></td>
                <td>${order.date}</td>
                <td>${order.customer}</td>
                <td>${order.items}</td>
                <td>R ${order.total.toFixed(2)}</td>
                <td>
                    <select class="status-select" onchange="updateOrderStatus('${order.id}', this.value)">
                        <option value="Pending" ${order.status === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Processing" ${order.status === 'Processing' ? 'selected' : ''}>Processing</option>
                        <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
                    </select>
                </td>
            </tr>
        `;
    });
}

window.updateOrderStatus = function(orderId, newStatus) {
    const order = orders.find(o => o.id === orderId);
    if(order) {
        order.status = newStatus;
        showToast(`Order status updated`);
        renderDashboard();
    }
}

function renderInventory() {
    inventoryTable.innerHTML = '';
    inventory.forEach(item => {
        const stockClass = item.stock < 20 ? 'status-low-stock' : 'status-in-stock';
        const stockText = item.stock < 20 ? 'Low Stock' : 'In Stock';
        inventoryTable.innerHTML += `
            <tr>
                <td><img src="${item.image}" class="product-img-thumb"></td>
                <td><strong>${item.name}</strong></td>
                <td>${item.sku}</td>
                <td>R ${item.price.toFixed(2)}</td>
                <td><strong>${item.stock}</strong></td>
                <td><span class="status-badge ${stockClass}">${stockText}</span></td>
            </tr>
        `;
    });
}

function renderPayments() {
    paymentsTable.innerHTML = '';
    let cash = 0, card = 0;
    
    orders.forEach((order, index) => {
        if(order.paymentMethod === 'Cash') cash += order.total;
        else card += order.total;

        paymentsTable.innerHTML += `
            <tr>
                <td>${order.id}</td>
                <td>${order.paymentMethod}</td>
                <td><strong>R ${order.total.toFixed(2)}</strong></td>
                <td>${order.date}</td>
            </tr>
        `;
    });

    totalCashPayments.textContent = `R ${cash.toLocaleString()}`;
    totalCardPayments.textContent = `R ${card.toLocaleString()}`;
}

function renderUsers() {
    if(currentUser?.role !== 'Admin') return; // Security check
    
    usersTable.innerHTML = '';
    appUsers.forEach(user => {
        const statusClass = user.status === 'Active' ? 'status-active' : 'status-inactive';
        
        // Cannot deactivate yourself
        const disableAction = user.id === currentUser.id;
        const toggleBtn = disableAction ? 
            `<span class="text-muted" style="font-size:0.8rem">Current</span>` : 
            `<button class="btn btn-sm ${user.status === 'Active' ? 'btn-outline-light' : 'btn-primary'}" 
               style="color: ${user.status === 'Active' ? 'var(--danger-red)' : 'white'}; border-color: ${user.status === 'Active' ? 'var(--danger-red)' : ''}"
               onclick="toggleUserStatus('${user.id}')">
               ${user.status === 'Active' ? 'Deactivate' : 'Activate'}
             </button>`;

        usersTable.innerHTML += `
            <tr>
                <td><strong>${user.name}</strong></td>
                <td>${user.email}</td>
                <td>${user.role}</td>
                <td><span class="status-badge ${statusClass}">${user.status}</span></td>
                <td>${toggleBtn}</td>
            </tr>
        `;
    });
}

window.toggleUserStatus = function(userId) {
    const user = appUsers.find(u => u.id === userId);
    if(user && user.id !== currentUser.id) {
        user.status = user.status === 'Active' ? 'Inactive' : 'Active';
        showToast(`${user.name} is now ${user.status}`);
        renderUsers();
    }
}

// ==========================================
// CUSTOMER SIMULATION LOGIC
// ==========================================

function renderCustomerProducts() {
    customerProductGrid.innerHTML = '';
    inventory.forEach(product => {
        customerProductGrid.innerHTML += `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}">
                <div class="product-card-body">
                    <h3>${product.name}</h3>
                    <p>SKU: ${product.sku}</p>
                    <div class="product-price-row">
                        <span class="product-price">R ${product.price.toFixed(2)}</span>
                        <button class="btn-add-cart" onclick="addToCart('${product.id}')"><i class="fa-solid fa-plus"></i></button>
                    </div>
                </div>
            </div>
        `;
    });
}

window.addToCart = function(productId) {
    const product = inventory.find(p => p.id === productId);
    if(!product) return;

    const existingItem = cart.find(item => item.id === productId);
    if(existingItem) existingItem.qty += 1;
    else cart.push({ ...product, qty: 1 });

    updateCartUI();
    showToast(`${product.name} added to cart!`);
}

function updateCartUI() {
    cartCount.textContent = cart.reduce((sum, item) => sum + item.qty, 0);
    cartItemsContainer.innerHTML = '';
    let totalAmount = 0;

    if(cart.length === 0) {
        cartItemsContainer.innerHTML = '<p class="text-center text-muted mt-4">Your cart is empty.</p>';
    } else {
        cart.forEach(item => {
            totalAmount += (item.price * item.qty);
            cartItemsContainer.innerHTML += `
                <div class="cart-item">
                    <img src="${item.image}">
                    <div class="cart-item-details">
                        <div class="cart-item-title">${item.name}</div>
                        <div class="cart-item-price">R ${(item.price * item.qty).toFixed(2)}</div>
                        <div class="cart-item-actions">
                            <button class="qty-btn" onclick="updateCartQty('${item.id}', -1)">-</button>
                            <span class="qty-value">${item.qty}</span>
                            <button class="qty-btn" onclick="updateCartQty('${item.id}', 1)">+</button>
                        </div>
                    </div>
                </div>
            `;
        });
    }
    cartTotalAmount.textContent = `R ${totalAmount.toFixed(2)}`;
}

window.updateCartQty = function(productId, change) {
    const item = cart.find(i => i.id === productId);
    if(item) {
        item.qty += change;
        if(item.qty <= 0) cart = cart.filter(i => i.id !== productId);
        updateCartUI();
    }
}

openCartBtn.addEventListener('click', () => { cartSidebar.classList.add('open'); cartOverlay.classList.remove('hidden'); });
closeCartBtn.addEventListener('click', closeCart);
cartOverlay.addEventListener('click', closeCart);
function closeCart() { cartSidebar.classList.remove('open'); cartOverlay.classList.add('hidden'); }

checkoutBtn.addEventListener('click', () => {
    if(cart.length === 0) return showToast('Cart is empty!');
    closeCart();
    checkoutModal.classList.remove('hidden');
});

cancelCheckoutBtn.addEventListener('click', () => checkoutModal.classList.add('hidden'));

confirmOrderBtn.addEventListener('click', () => {
    const spazaName = checkoutSpazaName.value || 'Test Spaza';
    const paymentMethod = checkoutPaymentMethod.value;
    const totalAmount = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
    
    orders.unshift({
        id: `ORD-${Math.floor(Math.random() * 9000) + 1000}`,
        customer: spazaName,
        date: new Date().toISOString().split('T')[0],
        items: totalItems,
        total: totalAmount,
        status: 'Pending',
        paymentMethod: paymentMethod
    });

    cart.forEach(cartItem => {
        const inventoryItem = inventory.find(i => i.id === cartItem.id);
        if(inventoryItem) inventoryItem.stock -= cartItem.qty;
    });

    cart = [];
    updateCartUI();
    checkoutModal.classList.add('hidden');
    showToast('Test Order placed successfully!');
    
    setTimeout(() => {
        customerSimulation.classList.add('hidden');
        switchView('dashboard-view');
        renderDashboard();
        renderOrders();
        renderInventory();
        renderPayments();
    }, 1500);
});

// ==========================================
// UTILS
// ==========================================
let toastTimeout;
function showToast(message) {
    toastMessage.textContent = message;
    toastNotification.classList.remove('hidden');
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => toastNotification.classList.add('hidden'), 3000);
}

// Start App
init();
